﻿using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;
using System.Windows;
using System.Windows.Media;
using test2;
namespace ArcGISApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private GraphicsOverlay mapGraphics;
        public MainWindow()
        {

             
             mapGraphics = new GraphicsOverlay();
            SettingsGUI gui = new SettingsGUI();
            gui.run();
            
            InitializeComponent();
            


            //Create a point geometry
            //var point = new MapPoint(-118.29507 + i, 34.13501 + i, SpatialReferences.Wgs84);
            var point = new MapPoint(100, 50, SpatialReferences.Wgs84);


            //Create point symbol with outline
            var pointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle.Diamond, System.Drawing.Color.FromArgb(226, 119, 40), 10);
                pointSymbol.Outline = new SimpleLineSymbol(SimpleLineSymbolStyle.Solid, System.Drawing.Color.FromArgb(0, 0, 255), 2);

                //Create point graphic with geometry & symbol
                var pointGraphic = new Graphic(point, pointSymbol);

                //Add point graphic to graphic overlay
                MapGraphics.Graphics.Add(pointGraphic);
            

        }

        
        // Map initialization logic is contained in MapViewModel.cs
    }
}
