﻿using System;
using ArcGISApp2;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
            MapViewModel model = new MapViewModel();

        }
    }
}
