﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test2
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
           
        }
        

        private void ChooseFileButton_Click(object sender, EventArgs e)
        {
            //OpenFileDialog od = new OpenFileDialog();
            //string fileName = od.FileName;
            string[] lines = { "100 50", "101 51", "102 52", "103 53"};
            System.IO.File.WriteAllLines(@"C:\Users\jljut\Desktop\test.txt", lines);
        }
       
    }
}
