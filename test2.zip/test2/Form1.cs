﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;
using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;

namespace test2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }


        private void ChooseFileButton_Click(object sender, EventArgs e)
        {
            //do error checks
            String minAge = MinAge.Text;
            String maxAge = MaxAge.Text;
            string gender = Gender.Text;
            string marital = Marital.Text;
            String education = Education.Text;





            MongoDB db = new MongoDB();
            db.GetFields();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }

    class MongoDB
    {
        private string marital;
        private int UpAge = 999;
        private int lowAge = 0;
        private string gender;
        private string education;
        //This is the default constructor

        //public MongoDB(string maxAge, string minAge, string marital, string gender, string education)

        //{
        //    if (int.TryParse(maxAge, out int result))
        //    {
        //        UpAge = result;
        //    }
        //    else
        //    {
        //        UpAge = 999;
        //    }

        //    if (int.TryParse(minAge, out int result2))
        //    {
        //        lowAge = result2;
        //    }
        //    else
        //    {
        //        lowAge = 0;
        //    }
        //    this.gender = gender;
        //    this.marital = marital;
        //    this.education = education;

        //    // 
        //    var credential = MongoCredential.CreateCredential("test", "Test_Admin", "drowssap");
        //    var settings = new MongoClientSettings
        //    {
        //        Credential = credential
        //        //Server = new MongoServerAddress(,Convert.ToInt32(ConfigurationManager.AppSettings["27017"]))
        //    };
        //    // var client = new MongoClient(settings);
        //    //
        //    var client = new MongoClient("mongodb+srv://Test_Admin:drowssap@hacktheu-htus5.gcp.mongodb.net/admin?retryWrites=true&w=majority");

        //    var database = client.GetDatabase("test");




        //    var collection = database.GetCollection<BsonDocument>("items");
        //    OpenFileDialog od = new OpenFileDialog();
        //    od.ShowDialog();

        //    string fileName = od.FileName;
        //    string json;
        //    string currentline;
        //    dynamic items;
        //    BsonDocument bson;
        //    // System.IO.StreamReader  jsonFile = new System.IO.StreamReader(fileName);
        //    using (StreamReader r = new StreamReader(fileName))
        //    {
        //         bson = BsonDocument.Parse(r.ReadToEnd());
        //        json = r.ReadToEnd();
        //       // items = JsonConvert.DeserializeObject(json);

        //    }

        //    collection.InsertOne(bson);

        //    collection = database.GetCollection<BsonDocument>("items");

        //    List<string> coordinates = new List<string>();
        //  //  Console.WriteLine(items.buyers[0].Coordinates);
        //    //for (int i = 0; i < items.buyers.Count; i++)
        //    //{
        //      //  Console.WriteLine(items.buyers[i].Coordinates);

        //       // if (EqualAge(lowAge,UpAge, (String)(items.buyers[i].Age)) && EqualGender(gender, (string)(items.buyers[i].Gender))
        //         //   && EqualMarital(marital, (string)(items.buyers[i].MaritalStatus)) && EqualEducation(education, (string)(items.buyers[i].EducationLevel)))
        //        //{
        //          //  coordinates.Add((string)(items.buyers[i].Coordinates));
        //        //}
        //    //}
        //    //C:\Users\jljut\Desktop\test.txt
        //    //System.IO.File.WriteAllLines(@"test.txt", coordinates.ToArray());
        //}

        public MongoDB()
        {
            keys = new List<string>();
        }

        List<String> keys;

        public string[] GetFields()
        {

            var credential = MongoCredential.CreateCredential("test", "Test_Admin", "drowssap");
            var settings = new MongoClientSettings
            {
                Credential = credential
                //Server = new MongoServerAddress(,Convert.ToInt32(ConfigurationManager.AppSettings["27017"]))
            };
            // var client = new MongoClient(settings);
            //
            var client = new MongoClient("mongodb+srv://Test_Admin:drowssap@hacktheu-htus5.gcp.mongodb.net/admin?retryWrites=true&w=majority");

            var database = client.GetDatabase("test");
            



            var collection = database.GetCollection<BsonDocument>("items");
            OpenFileDialog od = new OpenFileDialog();
            od.ShowDialog();

            string fileName = od.FileName;
            string json;
            string currentline;
            dynamic items;
            BsonDocument bson;
            // System.IO.StreamReader  jsonFile = new System.IO.StreamReader(fileName);
            using (StreamReader r = new StreamReader(fileName))
            {
                json = r.ReadToEnd();
                bson = BsonDocument.Parse(json);
                
                
                // items = JsonConvert.DeserializeObject(json);

            }
            int i = 0;
            int j;
            while(json.ElementAt(i) != '{')
            {
                i++;
            }
            while(json.ElementAt(i) != '[')
            {
                i++;
            }
            while(json.ElementAt(i) != '{')
            {
                i++;
            }
            bool breakOut = false;
 MainLoop:  while (true && !breakOut) { //code begins iterating through objects
                while (json.ElementAt(i) != '\"')
                {
                    if(json.ElementAt(i) == '}')
                    {
                        breakOut = true;
                        break;
                    }
                    i++;
                }

                i++;
                j = i;
                while (json.ElementAt(j) != '"')
                {
                    j++;
                }
                keys.Add(json.Substring(i, j));
                i = j;
                while (json.ElementAt(i) != '\n') {
                    i++;
                }
            }


            collection.InsertOne(bson);

            database = client.GetDatabase("test");
            collection = database.GetCollection<BsonDocument>("items");
            //todo
            return null;
        }

        private void recordCoordinatesFromFilter(IMongoDatabase db, string field, string restriction)
        {
            var options = new CreateIndexOptions();
            IMongoCollection<BsonDocument> collection = db.GetCollection<BsonDocument>("test");
            var query =
                from element in collection.AsQueryable<BsonDocument>()
                where element == restriction
                select element;
            
            foreach(string str in query)
            {
                //add to text file

            }
        }

        private void recordCoordinatesFromFilter(string filter, int lowRange, int highRange)
        {

        }

        private bool EqualAge(int min, int max, string age2)
        {
            if (int.TryParse(age2, out int result))
            {


                if (max > result && min < result)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        private bool EqualMarital(string original, string marital)
        {
            if (String.IsNullOrEmpty(original))
            {
                return true;
            }else if(original == marital)
            {
                return true;
            }
            return false;

        }

        private bool EqualGender(string original, string gender)
        {
            if (String.IsNullOrEmpty(original))
            {
                return true;
            }else if(original == gender)
            {
                return true;
            }
            return false;
        }
        private bool EqualEducation(string original, String education)
        {
            if (String.IsNullOrEmpty(original))
            {
                return true;
            }else if(original == education)
            {
                return true;
            }
            return false;
        }

        class buyer
        {
            public string Coordinates { get; set; }
            public int Age { get; set; }
            public string MaritalStatus { get; set; }
            public string Gender { get; set; }
            public string EducationLevel { get; set; }
        }



    }

}